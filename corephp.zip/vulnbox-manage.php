
<?php

// Include the database configuration file
include 'corephp-config.php';

// Create a new MySQLi connection
$conn = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch the core files from the database
$query = "SELECT * FROM vulnbox_core_files ORDER BY id DESC";

$result = $conn->query($query);
$results_core_files = [];


if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $results_core_files[] = $row;
    }
}

// Handle the update operation
if (isset($_POST['update_core'])) {
    $id = $_POST['id'];
    $uniqueId = $_POST['unique_id'];
    $filename = $_POST['filename'];
    $url = $_POST['url'];

    // Perform the update operation
    $query = "UPDATE vulnbox_core_files SET unique_id = '$uniqueId', filename = '$filename', url = '$url' WHERE id = '$id'";
    $conn->query($query);
}

// Handle the delete operation
if (isset($_POST['delete_core'])) {
    $id = $_POST['id'];

    // Perform the delete operation
    $query = "DELETE FROM vulnbox_core_files WHERE id = '$id'";
    $conn->query($query);
}

// Close the database connection
$conn->close();
?>




<html>
<body>

<!-- CORE FILES HTML SECTION START -->
<h1>Update core file here</h1>
<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Unique ID</th>
            <th>Filename</th>
            <th>URL</th>
            <th>Action</th>
            <th>Delete</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($results_core_files as $row) : ?>
            <tr>
                <form method="post" action="">
                    <td><input readonly type="text" name="id" value="<?php echo $row['id']; ?>"></td>
                    <td><input type="text" name="unique_id" value="<?php echo $row['unique_id']; ?>"></td>
                    <td><input type="text" name="filename" value="<?php echo $row['filename']; ?>"></td>
                    <td><input type="text" name="url" value="<?php echo $row['url']; ?>"></td>
                    <td>
                        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                        <input type="submit" name="update_core" value="Update">
                    </td>
                </form>
                <td>
                    <form method="post" action="">
                        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                        <input type="submit" name="delete_core" value="Delete">
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
<!-- CORE FILES HTML SECTION END -->

</body>
</html>
